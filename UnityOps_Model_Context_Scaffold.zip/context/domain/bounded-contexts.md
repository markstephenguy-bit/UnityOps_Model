- **QC** (Core): intake, validation, persistence, alerting
- **Ops Admin** (Supporting): user/role assignment, configuration
- **Reporting** (Generic/Later): aggregated read models and dashboards
Context relationships: QC publishes events consumed by Reporting.
