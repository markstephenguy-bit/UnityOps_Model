- ADRs mandatory for: platform changes, data retention, identity model
- Review gates:
  1) Context complete for a use-case (vision/use-case/NFRs)
  2) THEN model DSL work may start for that use-case only
