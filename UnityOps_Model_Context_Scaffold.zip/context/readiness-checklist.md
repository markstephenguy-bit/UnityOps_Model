**Context Ready for Modeling (per use-case)**
☐ Vision updated & measurable outcomes set
☐ Persona & scenarios written with acceptance criteria
☐ Capability map marks the area as “approved”
☐ Principles/constraints reviewed; no conflicts
☐ NFRs defined with numeric SLOs
☐ Risks & mitigations listed
☐ ADR(s) created if needed
→ When all boxes are checked, you may start the model framework for THIS use-case.
